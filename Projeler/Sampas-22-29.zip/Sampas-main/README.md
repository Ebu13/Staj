# Sampas
Alıştırma
