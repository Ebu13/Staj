// src/App.js
import React from 'react';
import Navbar from './components/Navbar';

function EmployeeHome() {
  return (
      <div>
        <Navbar/>
        <h1>Employee</h1>
      </div>
  );
}


export default EmployeeHome;
