// src/App.js
import React from 'react';
import Navbar from './Navbar';

function ProfilePage() {
  return (
      <div>
        <Navbar/>
        <h1>Profile Page</h1>
      </div>
  );
}


export default ProfilePage;
