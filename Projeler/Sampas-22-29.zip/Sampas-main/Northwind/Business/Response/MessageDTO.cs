﻿
namespace Northwind.Business.Response
{
    public partial class CategoryResponseDTO
    {
        public int CategoryId { get; set; }

        public string? CategoryName { get; set; }

        public string? Description { get; set; }

    }

}
