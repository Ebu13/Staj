﻿namespace Northwind.Business.Request
{
    public class LoginRequestDTO
    {
        public string Username { get; set; } = null!;

        public string Password { get; set; } = null!;
    }
}
