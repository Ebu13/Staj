﻿namespace Northwind.Business.Request
{
    public class ShipperRequestDTO
    {
        public int ShipperId { get; set; }

        public string? ShipperName { get; set; }

        public string? Phone { get; set; }

    }
}
