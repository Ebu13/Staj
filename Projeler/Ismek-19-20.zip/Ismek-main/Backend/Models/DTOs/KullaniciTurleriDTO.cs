﻿namespace Backend.Models.DTOs
{
    public class KullaniciTurleriDTO
    {
        public byte KullaniciTuruId { get; set; }

        public string KullaniciTuru { get; set; } = null!;
    }
}
