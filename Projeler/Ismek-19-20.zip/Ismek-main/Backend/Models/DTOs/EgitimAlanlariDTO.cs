﻿namespace Backend.Models.DTOs
{
    public class EgitimAlanlariDTO
    {
        public short EgitimAlaniId { get; set; }

        public string EgitimAlani { get; set; } = null!;

        public short EgitimDaliId { get; set; }
    }
}
