﻿namespace Backend.Models.DTOs
{
    public class EgitimTipleriDTO
    {
        public short EgitimTipiId { get; set; }

        public string EgitimTipi { get; set; } = null!;
    }
}
