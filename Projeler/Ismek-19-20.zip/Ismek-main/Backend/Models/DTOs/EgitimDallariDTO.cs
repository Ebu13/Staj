﻿namespace Backend.Models.DTOs
{
    public class EgitimDallariDTO
    {
        public short EgitimDaliId { get; set; }

        public string EgitimDali { get; set; } = null!;
    }
}
